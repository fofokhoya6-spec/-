
// server.js
require('dotenv').config();
const express = require('express');
const fetch = require('node-fetch');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 3000;
const OPENAI_KEY = process.env.OPENAI_API_KEY;

if (!OPENAI_KEY) {
  console.error("❌ ضع مفتاح API في ملف .env");
  process.exit(1);
}

app.get('/api/welcome', (req, res) => {
  res.json({ reply: "السلام عليكم ورحمة الله وبركاته، كيف أساعدك؟" });
});

app.post('/api/reply', async (req, res) => {
  const { message } = req.body;
  if (!message) return res.status(400).json({ error: 'الرسالة مفقودة' });

  try {
    const resp = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${OPENAI_KEY}`
      },
      body: JSON.stringify({
        model: "gpt-3.5-turbo",
        messages: [
          { role: "system", content: "أنت مساعد مكتبة عمومية. أجب على الأسئلة المتعلقة بالمكتبة فقط. أعط الإجابة بالعربية الفصحى، ثم أضف الترجمة الفرنسية أسفلها بين قوسين." },
          { role: "user", content: message }
        ],
        temperature: 0.2,
        max_tokens: 300
      })
    });

    const data = await resp.json();
    const reply = data.choices?.[0]?.message?.content || "لم أتمكن من الحصول على إجابة.";
    res.json({ reply });

  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'حدث خطأ في الخادم' });
  }
});

app.listen(PORT, () => {
  console.log(`✅ الخادم يعمل على المنفذ ${PORT}`);
});
